# myTV

Welcome to my IPTV Playlist

It's a personal playlist for my personal usage some link may be broken after a while, my main focus is Indonesia TV Channels and some entertainment channel. THIS IPTV MAINLY FOCUSED ON INDONESIAN TV.

Branch :
dev : Testing branch where some channel might not working properly                                                                 
master : A tested branch where only few channel that not working (maybe because of the service is dead)

Playlists :

iptv.m3u : A playlist of Working and *NOT* Working m3u iptv Channels                                                                    
useetv.m3u : A playlist of m3u iptv channels from UseeTV GO (useetv.com) which not working on KODI [DISCONTINUED]                                                           
sortedtv.m3u : A playlist of channel that working on Perfect Player and TiviMate (may not working on KODI)

Guide :

guide.xml : Guide for the playlist, it's not fully filled as of some channels not exist on certain services
